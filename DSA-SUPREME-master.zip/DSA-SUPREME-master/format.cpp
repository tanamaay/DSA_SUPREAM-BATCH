// related questions name or link

#include<iostream>
using namespace std;

int main(){

    int a;
    cin>>a;
    int b;
    cin>>b;
    int sum = add(a, b);
    cout << sum << '\n';

    return 0;
}

/*INPUTS
*/