// Below code should print the sum of ‘i’ and ‘j’.

#include<iostream>
using namespace std;

int main() {
	short i=2300, j=4322;
	cout<<"i+j="<<(i+j);
    
    return 0;
}