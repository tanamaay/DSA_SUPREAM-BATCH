#include<iostream>
using namespace std;
int main(){

    // cout<<"Namaste Bharat"<<'\n';

    /*// datatypes
        // int
        int a = 5;
        cout<<"value of a is " << a << endl;
        
        // char
        char ch = 'a';
        cout<<"value of ch is " << ch << endl;

        // bool
        bool flag = true;
        cout<<"value of flag is " << flag << endl;
    */

    /*// to check char range    compiler dependent
        char ch2 = 25;
        cout<<"value of ch2 is " << ch2 << endl;

        char ch3 = -120;
        cout<<"value of ch3 is " << ch3 << endl;

        // overflow
        char ch4 = -260;
        cout<<"value of ch4 is " << ch4 << endl;

        // overflow
        char ch5 = 260;
        cout<<"value of ch5 is " << ch5 << endl;
    */

    /*// sizeof()
        // int
        int a = 5;
        cout<<"size of a is " << sizeof(a) << endl;
        
        // char
        char ch = 'a';
        cout<<"size of ch is " << sizeof(ch) << endl;

        // bool
        bool flag = true;
        cout<<"size of flag is " << sizeof(flag) << endl;

        // float
        float f = 9.2;
        cout<<"size of f is " << sizeof(f) << endl;

        // double
        double d = 9.2;
        cout<<"size of d is " << sizeof(d) << endl;

        // long long
        long long ll = 23;
        cout<<"size of ll is " << sizeof(ll) << endl;

        // long
        long l = 23;
        cout<<"size of l is " << sizeof(l) << endl;

        // short
        short s = 23;
        cout<<"size of s is " << sizeof(s) << endl;
    */

    /*// typecasting
        // implicit typecasting
            char ch = 97;
            cout<<ch<<'\n';

            int num = 'b';
            cout<<num<<'\n';

        // explicit typecasting
            ch = char(97);
            cout<<ch<<'\n';

            float f = (float)'a';
            cout<<f<<'\n';

            f = (float)('a' + 2);
            cout<<f<<'\n';

            double d = 5.7;
            int x = (int)(d+2);
            cout<<x<<'\n';

        // overflow example
            ch = 9999;
            cout<<ch<<'\n';
    */
    
    // operators
        /*// arithmatic operators
            cout << 2 + 3 << '\n';
            cout << 2 - 3 << '\n';
            cout << 2 * 3 << '\n';
            cout << 2 / 3 << '\n';
            cout << 2 % 3 << "\n\n";

            cout << 2.0 / 3 << '\n';
            cout << 2 / 3.0 << '\n';
            cout << 2.0 / 3.0 << "\n\n";

            cout << (double)2 / 3 << '\n';
            cout << 2 / (double)3 << '\n';
            cout << (double)2 / (double)3 << '\n';
        */

        /*// relational operators
            int a=5;
            int b=3;
            cout<<(a>b)<<'\n';
            cout<<(a<b)<<'\n';
            cout<<(a>=b)<<'\n';
            cout<<(a<=b)<<'\n';
            cout<<(a!=b)<<'\n';
            cout<<(a==b)<<'\n';
        */

        /*// assignment operators
            int a=5;
            int b=a;
        */

        /*// logical operators
            int a=5;
            int b=3;
            // and &&
                cout << (a>=5 && b<=3) << '\n';
                cout << (a<5 && b>=3) << '\n';
                cout << (a<=5 && b>3) << '\n';
                cout << (a<5 && b>3) << "\n\n";

            // or ||
                cout << (a>=5 || b<=3) << '\n';
                cout << (a<5 || b>=3) << '\n';
                cout << (a<=5 || b>3) << '\n';
                cout << (a<5 || b>3) << "\n\n";

            // not !
                cout << (a<5) <<'\n';
                cout << !(a<5) <<'\n';
                cout << (a==5) <<'\n';
                cout << !(a==5) <<"\n\n";
        */
    
}