// The below code snippet has some errors. Let’s debug it and make it compile & run successfully.

#include<iostream>
using namespace std;

int main() {
	int i=0;
	i=i+1;
	cout<<i;
	/*print i \*/
    i=i+1;
	cout<<++i;

    return 0;
}