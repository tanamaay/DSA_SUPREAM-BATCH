#include<iostream>
using namespace std;

int main(){

    /*// print 1 to 5
        for(int i=0; i<=5; i++){
            cout<<i<<' ';
        }
    */

    /*// check prime or not
        int n;
        cin>>n;
        bool flag = 1;
        for(int i=2; i<n; i++){
            if(n%i==0){
                flag=0;
            }
        }
        if(flag==0){
            cout<<"Not a prime";
        }
        else{
            cout<<"prime";
        }
    */

    // endl can be used as variable name
    /*// overflow case
        char endl = 234235;
        cout<<endl<<'\n';
    */

    // addition and subtraction
        /*int a = 5;
        char b = 'd';
        int sum = a+b;
        cout << sum <<'\n';
        float f= 2.0 + sum;
        cout << f << '\n';
        */

        /*float f = 2.7;
        int n = 157;
        int diff = n-f;
        cout<<diff<<'\n';
        */

        /*int a = 25;
        float b = 3.5;
        float diff = a-b;
        cout << diff;
        */

    // if else-if else condition without {}
        /*if(true)
            cout<<"hello\n";
        else
            cout<<"hi\n";
        */
    
    return 0;
}