#include<iostream>
using namespace std;
int main(){

    /*
    int a = 5;
    cout << (++a) * (++a)<<'\n';
    */

    return 0;
}