#include<iostream>
using namespace std;
int main(){

    int arr[]={};
    cout<<sizeof(arr);

    return 0;
}